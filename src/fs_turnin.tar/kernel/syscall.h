#ifndef KERNEL_SYSCALL_H
#define KERNEL_SYSCALL_H

void syscall_init (void);
void syscall_exit (void);

#endif /* kernel/syscall.h */
